import { initializeApp } from 'firebase/app';

// TODO: Replace the following with your app's Firebase project configuration
const firebaseConfig = {
    apiKey: "AIzaSyAL8DiuQ4pO--yxoqJ1UxxV0O1jRp1o5ds",
    authDomain: "project-for-os.firebaseapp.com",
    databaseURL: "https://project-for-os-default-rtdb.asia-southeast1.firebasedatabase.app",
    projectId: "project-for-os",
    storageBucket: "project-for-os.appspot.com",
    messagingSenderId: "59124588906",
    appId: "1:59124588906:web:8ab791fd1713071cbb8513",
    measurementId: "G-RMMJFQXS20"
};
const app = initializeApp(firebaseConfig);
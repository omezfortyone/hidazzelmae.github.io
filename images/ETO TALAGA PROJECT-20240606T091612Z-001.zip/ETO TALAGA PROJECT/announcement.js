$(document).ready(function () {
  $("#addEventBtn").click(function () {
    $("#addEventForm").toggle();
  });

  $("#eventForm").submit(function (event) {
    event.preventDefault();

    var eventName = $("#eventName").val();
    var eventDate = $("#eventDate").val();

    // Add event to calendar
    $("#calendar").fullCalendar(
      "renderEvent",
      {
        title: eventName,
        start: eventDate,
        allDay: true,
      },
      true
    );

    $("#eventForm")[0].reset();
    $("#addEventForm").hide();
  });

  $("#calendar").fullCalendar({
    dayClick: function (date, jsEvent, view) {
      var eventDate = date.format("YYYY-MM-DD");
      $("#eventDate").val(eventDate);
      $("#addEventForm").show();
    },
  });

  setInterval(function () {
    var now = new Date();

    $("#calendar").fullCalendar("clientEvents", function (event) {
      var eventStart = event.start.toDate();

      if (eventStart <= now && !event.postedToAnnouncement) {
        var eventHtml = "<div class='event'>";
        eventHtml += "<h3>" + event.title + "</h3>";
        eventHtml += "<p>" + event.start.format("YYYY-MM-DD") + "</p>";
        eventHtml += "</div>";

        $(".announcement").append(eventHtml);

        event.postedToAnnouncement = true;
      }
    });
  }, 1000);
});
